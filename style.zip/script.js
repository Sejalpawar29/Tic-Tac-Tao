document.getElementById('start-game').addEventListener('click', () => {
    const gridSize = parseInt(document.getElementById('grid-size').value);
    const winStreak = parseInt(document.getElementById('win-streak').value);

    if (winStreak > gridSize) {
        alert("Win streak can't be larger than the grid size!");
        return;
    }

    startGame(gridSize, winStreak);
});

function startGame(gridSize, winStreak) {
    const gameBoard = document.getElementById('game-board');
    gameBoard.innerHTML = '';
    gameBoard.style.gridTemplateColumns = repeat(${gridSize}, 1fr);

    let currentPlayer = 'X';
    const board = Array(gridSize).fill(null).map(() => Array(gridSize).fill(null));
    let gameOver = false;

    const gameStatus = document.getElementById('game-status');
    const restartButton = document.getElementById('restart-game');

    gameStatus.textContent = '';
    restartButton.style.display = 'none';

    for (let row = 0; row < gridSize; row++) {
        for (let col = 0; col < gridSize; col++) {
            const cell = document.createElement('button');
            cell.addEventListener('click', () => handleClick(row, col, cell));
            gameBoard.appendChild(cell);
        }
    }

    function handleClick(row, col, cell) {
        if (board[row][col] || gameOver) return;

        board[row][col] = currentPlayer;
        cell.textContent = currentPlayer;

        if (checkWin(row, col, currentPlayer)) {
            gameStatus.textContent = Player ${currentPlayer} wins!;
            gameOver = true;
            showRestart();
        } else if (board.flat().every(cell => cell !== null)) {
            gameStatus.textContent = It's a draw!;
            showRestart();
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        }
    }

    function checkWin(row, col, player) {
        // Check rows, columns, and diagonals
        return checkDirection(row, col, player, 0, 1) ||  // Horizontal
               checkDirection(row, col, player, 1, 0) ||  // Vertical
               checkDirection(row, col, player, 1, 1) ||  // Diagonal
               checkDirection(row, col, player, 1, -1);   // Anti-diagonal
    }

    function checkDirection(row, col, player, rowDir, colDir) {
        let count = 1;
        let r = row + rowDir;
        let c = col + colDir;

        while (r >= 0 && r < gridSize && c >= 0 && c < gridSize && board[r][c] === player) {
            count++;
            r += rowDir;
            c += colDir;
        }

        r = row - rowDir;
        c = col - colDir;

        while (r >= 0 && r < gridSize && c >= 0 && c < gridSize && board[r][c] === player) {
            count++;
            r -= rowDir;
            c -= colDir;
        }

        return count >= winStreak;
    }

    function showRestart() {
        restartButton.style.display = 'block';
        restartButton.addEventListener('click', () => {
            startGame(gridSize, winStreak);
        });
    }
}